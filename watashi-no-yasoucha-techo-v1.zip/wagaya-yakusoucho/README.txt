私の野草茶手帳 v1

【GitHubへのアップロード】
1. GitHubの mnnnnn127/wagaya-yakusoucho を開く
2. uploading an existing file を押す
3. このZIPを展開し、index.html をアップロード
4. Commit changes を押す

【GitHub Pages公開】
Repository → Settings → Pages
Build and deployment: Deploy from a branch
Branch: main / (root) → Save

公開URL（設定後）:
https://mnnnnn127.github.io/wagaya-yakusoucho/

【実装済み】
・タイトル「私の野草茶手帳」
・指定背景画像（軽量化してindex.html内へ埋め込み）
・3列×2段の6メニュー
・野草帳（Supabase保存・検索）
・野草の新規登録
・100gブレンド計算
・写真付き野草茶日記（写真自動圧縮）
・過去の日記・レシピ
・教室の基本ノート
・Supabase接続済み

注意：現v1は個人利用向けです。公開URLを他人に広く共有する前に、ログイン認証/RLSを個人専用に強化してください。
